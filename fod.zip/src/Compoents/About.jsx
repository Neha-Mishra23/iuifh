import React from 'react'

const About = () => {
  return (
    <div>
        <p>orem ipsum dolor sit amet consectetur adipisicing elit. Doloremque, voluptatem? Ipsam, alias quae. Sequi officiis quibusdam quia atque laborum, aliquid magnam repellat voluptas neque, beatae, modi dignissimos similique consequuntur quam.
Expedita quidem labore sit dolorem esse, recusandae quisquam eos. Ea enim iste sint quod repellat laudantium sit ducimus obcaecati tempora temporibus incidunt accusamus quia maiores et quisquam dolores, atque architecto.
Cumque quo molestiae praesentium nisi tenetur. Necessitatibus deleniti, dolor possimus ipsum architecto perspiciatis vero laboriosam minima debitis sed natus minus temporibus culpa quas, modi nam officia doloremque porro quo totam!
Iusto fugiat illo, omnis nulla quos ut ipsam atque. Impedit tempora fugiat doloremque corrupti eveniet saepe dignissimos, ab, repudiandae vitae iusto laborum facilis, iure aspernatur magnam. Enim accusamus perspiciatis aspernatur!
Porro, eaque enim? Quaerat vel possimus tenetur, necessitatibus perferendis molestiae dicta quos magni non sequi ratione aliquam, reprehenderit iusto enim saepe omnis qui cupiditate exercitationem, voluptatibus reiciendis? Similique, id. Aperiam?
Sequi explicabo corrupti, odit saepe facilis cum dicta nihil aliquid architecto magnam dolore, officiis ex omnis molestias. Cumque qui hic facilis, nesciunt laboriosam magnam eligendi totam repudiandae error possimus provident?
Dolor, labore, quaerat facere iure eius eligendi sapiente sed consequatur dolorem, laudantium iste! Repudiandae autem explicabo cupiditate rerum quaerat et vel laborum veniam sunt, soluta, quo expedita obcaecati, omnis ea?
Nemo quis neque in, sed dignissimos perferendis quasi aperiam. Molestiae sit animi, esse odit repellendus necessitatibus officiis illo doloremque error voluptas? Earum consequatur non, dolor minima enim facilis excepturi tenetur?
Temporibus placeat velit animi, necessitatibus eligendi doloremque fuga odit quis quod veniam rem similique iste sed, nam exercitationem quidem inventore, explicabo doloribus eveniet ullam accusamus ad. Impedit vel delectus eveniet!
Sint voluptatem adipisci ea dolore, ab saepe quidem iure tempore magni reprehenderit voluptate alias accusamus eius rem sequi vero esse. Dolor, modi? Deserunt, soluta! Enim repellendus fugiat hic error nemo!
Eum consectetur facilis ducimus quo! Quos explicabo magni facere hic totam reiciendis sit qui cupiditate alias numquam ipsa eius ut temporibus suscipit quo earum, non eos mollitia expedita ab saepe?
Inventore praesentium dolorum officia minus esse atque at, aliquid debitis! Sapiente fuga corrupti nam aperiam exercitationem molestiae amet soluta quia! Rerum, reiciendis voluptatibus! Ipsum minima eaque soluta rerum saepe alias.
Illo officiis quisquam dolor porro vitae earum, ratione deserunt vero perferendis eveniet saepe tempora recusandae debitis consequuntur beatae cupiditate obcaecati, ducimus deleniti, molestiae atque nulla sequi aut sunt? Alias, nam!
Adipisci nihil, quisquam quidem veritatis perferendis magni similique consequatur ut laudantium voluptatibus aut accusantium minima, dicta officiis id quam sint cumque error libero commodi. Laborum corrupti inventore dicta et soluta?
Consectetur laboriosam delectus quisquam a aliquid? Dolorum nemo hic ipsam eius similique vel vero, distinctio ad voluptas soluta in nostrum quasi excepturi ea natus corrupti accusantium omnis alias, dicta molestias?
Obcaecati minima sunt accusantium eos quibusdam velit repudiandae quos quae itaque recusandae, incidunt eum nihil? Quam, consequatur quasi modi aliquid tenetur exercitationem cupiditate quae recusandae aperiam numquam, facilis, animi natus.
Dolor beatae expedita necessitatibus eveniet nam veniam quos asperiores repudiandae impedit dolores, explicabo sed odio! Similique itaque quos accusamus dolores nobis est cum voluptatum quasi, officiis facilis veritatis dolor esse.
Obcaecati, sunt quia perferendis consequuntur debitis laudantium, vitae amet ea placeat quidem dolores nostrum nulla sit optio provident architecto ipsa porro blanditiis libero praesentium mollitia voluptas accusantium maxime. Minus, molestiae?
Autem eum nam minima veniam, cumque sit ipsa nesciunt vitae, quibusdam at unde repellat. Numquam quibusdam accusantium, ullam quis laborum sunt nisi quae. Eius, ducimus deleniti. Ducimus natus porro quasi!
Deserunt molestias recusandae ad, in fuga excepturi. Voluptatum placeat hic recusandae repellendus neque itaque voluptatem, nostrum natus ut saepe architecto et soluta vitae? Dolorem molestiae earum deserunt amet itaque sed!</p>
    </div>
  )
}

export default About
